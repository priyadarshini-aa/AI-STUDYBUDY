# Solution Architecture

Client/API requests → Express routes → middleware → controllers → MongoDB/Gemini services.

Main layers: routes, middleware, controllers, models, and utilities.
