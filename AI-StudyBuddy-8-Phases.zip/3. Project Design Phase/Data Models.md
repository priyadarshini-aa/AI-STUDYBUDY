# Data Models

User model stores account and role information.
Material model stores uploaded study-material information and generated AI content.
