# Project Documentation

See the project README and source code documentation for setup, API endpoints, project structure, authentication, database connection, and AI integration.
