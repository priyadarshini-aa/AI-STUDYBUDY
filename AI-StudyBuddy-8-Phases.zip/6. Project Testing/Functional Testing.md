# Functional Testing

Check successful requests, invalid credentials, missing authentication, invalid material IDs, file upload validation, and admin-only access.
