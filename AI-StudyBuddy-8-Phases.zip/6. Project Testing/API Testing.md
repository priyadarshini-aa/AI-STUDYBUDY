# API Testing

Test registration, login, refresh, logout, material upload/list/get/delete, AI endpoints, and admin endpoints. Verify authentication and role restrictions for protected routes.
