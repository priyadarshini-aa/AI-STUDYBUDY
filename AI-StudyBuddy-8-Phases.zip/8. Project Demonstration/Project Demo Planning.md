# Project Demo Planning

1. Start MongoDB
2. Configure `.env`
3. Run the Node.js API
4. Register/login a user
5. Upload a study material
6. Demonstrate summary/flashcards/quiz/study-plan APIs
7. Demonstrate admin APIs
8. Explain project architecture and future scope
