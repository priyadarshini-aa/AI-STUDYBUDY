# Solution Requirements

- User registration and login
- JWT-based authentication
- Student/admin role-based access
- Study-material upload and management
- AI summary, flashcard, quiz, and study-plan generation
- Admin user and statistics management
