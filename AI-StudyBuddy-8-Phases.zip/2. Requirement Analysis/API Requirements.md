# API Requirements

Authentication: `/api/auth`
Materials: `/api/materials`
Admin: `/api/admin`
