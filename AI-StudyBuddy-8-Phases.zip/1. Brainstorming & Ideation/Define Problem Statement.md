# Define Problem Statement

Students need a centralized backend to upload study materials, organize them, and use AI to turn those materials into useful study resources.
