# Brainstorming & Idea Prioritization

**Project:** AI StudyBuddy API

AI-powered educational backend for managing study materials and generating summaries, flashcards, quizzes, and personalized study plans.
